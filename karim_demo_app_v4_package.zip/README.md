
KaramTrade Private - v4
=======================
This package is a PRIVATE demo build prepared for Karam (كرم).
App name: كرم تريد — KaramTrade (Private)
Admin username: karam
Admin password: Akram@Krm2025

What I prepared:
- frontend/  -> Expo React Native project (user app)
- admin_app/ -> Expo React Native project (admin control, uses the admin username/password above)
- backend/   -> Minimal demo backend (optional for advanced features)

Important notes for phone-only setup:
- To install the app on your phone without a computer, I need to produce APK files.
- I can build the APKs for you using a build service (Expo EAS) if you allow me to use a build account to create the APKs and provide direct download links.
- OR I can publish the projects to Expo and give you an Expo link you open in Expo Go (no APK needed). This is faster but requires using Expo Go app on your phone.

Choose one option and I'll proceed:
A) I build APKs for you (I will use a build service and provide the download links).
B) I publish projects to Expo and give you Expo links to open with Expo Go.

Security:
- Admin password is set to the strong password you approved: Akram@Krm2025
- The private build will not be publicly published unless you ask.

