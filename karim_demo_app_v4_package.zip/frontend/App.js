import React, { useState } from 'react';
import { SafeAreaView, View, Text, TouchableOpacity, TextInput, StyleSheet, ScrollView } from 'react-native';

/*
  KaramTrade - Private build (display name and Islamic/Standard account)
  NOTE: This is a demo build for private use by Karam (كرم).
*/

const translations = {
  ar: { welcome: 'مرحبًا بك في كرم تريد', chooseAccount: 'اختر نوع الحساب', islamic: 'حساب إسلامي', standard: 'حساب عادي', start: 'ابدأ', namePlaceholder: 'اسم المستخدم', dashboard:'لوحة التحكم', balance:'الرصيد' },
  en: { welcome: 'Welcome to KaramTrade', chooseAccount: 'Choose account type', islamic: 'Islamic Account', standard: 'Standard Account', start: 'Get started', namePlaceholder: 'Username', dashboard:'Dashboard', balance:'Balance' }
};

export default function App() {
  const [lang,setLang] = useState('ar');
  const t = translations[lang];
  const [screen,setScreen] = useState('onboard');
  const [username,setUsername] = useState('');
  const [accountType,setAccountType] = useState('islamic'); // default Islamic
  const [balance,setBalance] = useState(250.00);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}><Text style={styles.title}>كرم تريد — KaramTrade (Private)</Text></View>

      {screen === 'onboard' && (
        <View style={styles.card}>
          <Text style={styles.h1}>{t.welcome}</Text>
          <Text style={{marginBottom:8}}>{t.chooseAccount}:</Text>
          <View style={{flexDirection:'row', marginBottom:12}}>
            <TouchableOpacity style={[styles.choice, accountType==='islamic' && styles.choiceActive]} onPress={()=>setAccountType('islamic')}><Text>{t.islamic}</Text></TouchableOpacity>
            <TouchableOpacity style={[styles.choice, accountType==='standard' && styles.choiceActive]} onPress={()=>setAccountType('standard')}><Text>{t.standard}</Text></TouchableOpacity>
          </View>
          <TextInput placeholder={t.namePlaceholder} value={username} onChangeText={setUsername} style={styles.input} />
          <TouchableOpacity style={styles.btn} onPress={()=>setScreen('dashboard')}><Text style={{color:'white'}}>{t.start}</Text></TouchableOpacity>
        </View>
      )}

      {screen === 'dashboard' && (
        <ScrollView contentContainerStyle={styles.card}>
          <Text style={styles.h2}>{t.dashboard}</Text>
          <Text>نوع الحساب: {accountType === 'islamic' ? t.islamic : t.standard}</Text>
          <View style={{marginTop:12}}>
            <Text style={styles.label}>{t.balance}:</Text>
            <Text style={styles.value}>{balance} USD</Text>
          </View>
          <TouchableOpacity style={[styles.btn,{marginTop:16}]} onPress={() => setBalance(b => b + 10)}><Text style={{color:'white'}}>محاكاة ربح +10</Text></TouchableOpacity>
        </ScrollView>
      )}

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container:{flex:1, backgroundColor:'#F7F8FA'},
  header:{padding:16, alignItems:'center'},
  title:{fontSize:18, fontWeight:'700'},
  card:{padding:20, margin:12, backgroundColor:'#fff', borderRadius:12},
  h1:{fontSize:20, fontWeight:'700', marginBottom:12},
  input:{borderWidth:1,borderColor:'#ddd',padding:10,borderRadius:8,marginBottom:12},
  btn:{backgroundColor:'#0A84FF',padding:12,borderRadius:10,alignItems:'center'},
  label:{fontWeight:'600'}, value:{fontWeight:'700', marginTop:6},
  choice:{padding:10, backgroundColor:'#eee', borderRadius:8, marginRight:8},
  choiceActive:{backgroundColor:'#dfefff'}
});
