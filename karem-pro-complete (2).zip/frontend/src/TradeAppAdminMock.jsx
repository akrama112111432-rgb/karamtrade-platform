import React from 'react';
export default function AdminMock(){ return (<div style={{fontFamily:'sans-serif',padding:20}}><h1>Karem Pro - Admin Mock</h1><p>Connect to server for full features.</p></div>) }
