# كرم برو - Backend (Staging)
هذه نسخة مبدئية لخادم تطبيقك "كرم برو" مع دعم تجربة مجانية، حدود شات بشري، واجهة AI (قابلة للربط مع OpenAI)، وStripe (sandbox).

## خطوات سريعة لتشغيل محليًا
1. فك الضغط وتشغيل:

   ```bash
   cd trade_app_karam_pro
   npm install
   cp .env.example .env
   # ضع مفاتيح Stripe و OpenAI في .env
   node migrate.js
   npm start
   ```

2. نقاط نهاية مهمة:
   - POST /register  -> { name, email }  (يفعل تجربة مجانية 7 أيام)
   - POST /create-checkout-session -> { user_id, plan }  (يرجع رابط Stripe Checkout)
   - POST /webhook/stripe  -> (stripe webhook handler)
   - POST /api/ai/chat -> requires header x-user-id and optional x-subscriber
   - POST /api/human/chat -> requires header x-user-id and optional x-subscriber

3. ملاحظات:
   - إذا لم تقم بإضافة OPENAI_API_KEY، سيُعاد رد تجريبي بدلًا من استدعاءات AI الحقيقية.
   - استخدم STRIPE_WEBHOOK_SECRET من لوحة Stripe عند إنشاء webhook (تأكد أن endpoint يقبل POST خام مع التوقيع).

4. اسم التطبيق مضمن في الكود: "كرم برو" — يمكنك تغييره في server.js متغير APP_NAME.

5. نشر:
   - يمكنك نشر الخادم على Render, Heroku, Railway أو أي VPS.
   - بعد النشر، حدّث روابط success_url و cancel_url في create-checkout-session.

## ماذا أفعل لك بعد هذا؟
- أستطيع نشر الخادم على خدمة سحابية تجريبية لك، أو أقدّم خطوات ونصوص جاهزة لرفع التطبيق إلى Google Play / App Store (سأحتاج منك بيانات الحسابات للقيام بذلك أو تقوم أنت بالرفع وأرشدك خطوة بخطوة).

## ملفات مرفقة
- server.js (الخادم)
- migrations/001_init.sql
- utils/db.js
- middleware/*
- .env.example
