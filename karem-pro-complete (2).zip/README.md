Karem Pro - Complete repository (ready for GitHub & Render)

This package contains 3 main folders: server/, frontend/, mobile/

To publish to GitHub and deploy on Render:
1. Create a new repository on your GitHub account named 'karem-pro' (or any name).
2. On your computer:
   git init
   git add .
   git commit -m "Initial commit - Karem Pro"
   git branch -M main
   git remote add origin https://github.com/YOUR_GITHUB_USERNAME/karem-pro.git
   git push -u origin main
3. In Render: choose 'Web Service' -> 'Connect a repo' -> select this repository and deploy.
4. After deploy, copy the public URL and replace API_BASE in mobile/App.js then build APK if needed.

Quick notes:
- Copy .env.example files to .env and fill STRIPE and OPENAI keys before deploying server to production.
- Use stripe test keys for sandbox.
- For admin access, insert an admin user into the DB as described in server/README_SERVER.md
