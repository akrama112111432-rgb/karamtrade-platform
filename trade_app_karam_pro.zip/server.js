const express = require('express');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const cors = require('cors');
const stripeLib = require('stripe');
const Database = require('./utils/db');
const aiGuard = require('./middleware/aiRequestGuard');
const humanQuota = require('./middleware/requireHumanQuota');
const fs = require('fs');
const path = require('path');
dotenv.config();
const app = express();
app.use(cors());
app.use(bodyParser.json());
const db = Database.get();
const STRIPE_SECRET = process.env.STRIPE_SECRET_KEY || 'sk_test_xxx';
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || 'whsec_xxx';
const stripe = stripeLib(STRIPE_SECRET);
const OPENAI_KEY = process.env.OPENAI_API_KEY || null;
const ADMIN_SECRET = process.env.ADMIN_SECRET || 'admin_secret_change';
const APP_NAME = 'كرم برو';
// Simple auth stub: header x-user-id and x-subscriber (1 or 0)
app.use((req,res,next)=>{
  const uid = req.header('x-user-id');
  if (!uid) return next();
  req.user = { id: Number(uid), is_subscriber: req.header('x-subscriber')==='1' };
  next();
});

// Health
app.get('/', (req,res)=> res.json({ ok:true, app: APP_NAME }));

// Register user and give free trial
app.post('/register', (req,res)=>{
  const { name, email } = req.body;
  if (!email) return res.status(400).json({ error: 'email required' });
  const exists = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (exists) return res.json({ ok:true, user: exists, message: 'user exists' });
  const now = new Date();
  const expires = new Date(now.getTime() + (7*24*60*60*1000));
  const info = db.prepare('INSERT INTO users (name,email,trial_starts_at,trial_expires_at) VALUES (?,?,?,?)').run(name||'', email, now.toISOString(), expires.toISOString());
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
  // init human counter
  db.prepare('INSERT OR REPLACE INTO human_chat_counters (user_id, used_messages, free_quota) VALUES (?,0,50)').run(user.id);
  res.json({ ok:true, user, trial_expires_at: expires.toISOString(), message: 'Free trial activated for 7 days' });
});

// Create Stripe checkout session (test)
app.post('/create-checkout-session', async (req,res)=>{
  const { user_id, plan } = req.body;
  if (!user_id || !plan) return res.status(400).json({ error:'user_id and plan required' });
  const priceMap = { 'standard_monthly': 1499, 'pro_yearly': 9999 }; // in cents
  const price = priceMap[plan] || 1499;
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{ price_data: { currency: 'usd', product_data: { name: APP_NAME + ' - ' + plan }, unit_amount: price }, quantity:1 }],
      mode: 'payment',
      success_url: 'https://example.com/success?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: 'https://example.com/cancel',
      metadata: { user_id: String(user_id), plan }
    });
    res.json({ ok:true, sessionId: session.id, url: session.url });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Stripe webhook to activate subscription
app.post('/webhook/stripe', express.raw({ type: 'application/json' }), (req,res)=>{
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.log('Webhook signature error', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const userId = session.metadata && session.metadata.user_id ? Number(session.metadata.user_id) : null;
    const plan = session.metadata && session.metadata.plan ? session.metadata.plan : 'standard_monthly';
    if (userId) {
      const now = new Date();
      const end = new Date(now.getFullYear()+1, now.getMonth(), now.getDate());
      db.prepare('UPDATE users SET is_subscriber = 1, subscriber_tier = ? WHERE id = ?').run(plan, userId);
      db.prepare('INSERT INTO subscriptions (user_id, plan, status, start_date, end_date, stripe_session_id) VALUES (?,?,?,?,?,?)').run(userId, plan, 'active', now.toISOString(), end.toISOString(), session.id);
      console.log('Activated subscription for user', userId);
    }
  }
  res.json({ received: true });
});

// AI chat endpoint
app.post('/api/ai/chat', async (req,res)=>{
  const user = req.user;
  if (!user) return res.status(401).json({ error: 'مستخدم غير مصدق.' });
  // use aiRequestGuard logic inline
  const { isComplexRequest } = require('./middleware/aiRequestGuard');
  const complex = isComplexRequest(req);
  if (complex && !user.is_subscriber) return res.status(403).json({ error: 'هذه الميزة متاحة للمشتركين فقط.' });

  // track usage
  const today = new Date().toISOString().slice(0,10);
  const row = db.prepare('SELECT requests FROM ai_usage_daily WHERE user_id = ? AND date = ?').get(user.id, today);
  const freeDailyLimit = user.is_subscriber ? 1000000 : 10;
  if (row && row.requests >= freeDailyLimit) return res.status(429).json({ error: 'وصلت الحد اليومي من طلبات المساعد الذكي.' });
  if (row) db.prepare('UPDATE ai_usage_daily SET requests = requests + 1 WHERE user_id = ? AND date = ?').run(user.id, today);
  else db.prepare('INSERT INTO ai_usage_daily (user_id, date, requests) VALUES (?, ?, 1)').run(user.id, today);

  // If OPENAI key not set, return a mock reply
  if (!OPENAI_KEY) {
    return res.json({ reply: 'هذه استجابة تجريبية للذكاء الاصطناعي (مفتاح OpenAI غير مفعّل).' });
  }

  // call OpenAI
  try {
    const OpenAI = require('openai');
    const client = new OpenAI({ apiKey: OPENAI_KEY });
    const prompt = `أنت مساعد ${APP_NAME} التعليمي. تكلّم بالعربية البسيطة وقدم تحذير المخاطر.` + '\nUser: ' + (req.body.text||'');
    const completion = await client.chat.completions.create({ model:'gpt-4o-mini', messages:[{role:'system', content:prompt},{role:'user', content:req.body.text}], max_tokens:800 });
    const reply = completion.choices[0].message.content;
    res.json({ reply });
  } catch (e) {
    console.error('OpenAI error', e.message);
    res.status(500).json({ error: 'خطأ في مزوّد الذكاء الاصطناعي.' });
  }
});

// Human chat endpoint
app.post('/api/human/chat', humanQuota, (req,res)=>{
  const user = req.user;
  // save message to chat_messages (sessionless simple)
  db.prepare('INSERT INTO chat_messages (session_id, sender, message_text, metadata) VALUES (?,?,?,?)').run(null, 'user', req.body.text||'', JSON.stringify({ user_id: user.id }));
  res.json({ ok:true, message: 'تم إرسال الرسالة إلى فريق الدعم (وضع تجريبي).' });
});

// Admin: toggle trial or expire (protected by ADMIN_SECRET header)
app.post('/admin/activate-trial', (req,res)=>{
  const secret = req.header('x-admin-secret');
  if (secret !== ADMIN_SECRET) return res.status(403).json({ error: 'Unauthorized' });
  const { user_id } = req.body;
  if (!user_id) return res.status(400).json({ error: 'user_id required' });
  const now = new Date();
  const expires = new Date(now.getTime() + (7*24*60*60*1000));
  db.prepare('UPDATE users SET trial_starts_at = ?, trial_expires_at = ? WHERE id = ?').run(now.toISOString(), expires.toISOString(), user_id);
  db.prepare('INSERT OR REPLACE INTO human_chat_counters (user_id, used_messages, free_quota) VALUES (?,0,50)').run(user_id);
  res.json({ ok:true, message: 'Trial activated', trial_expires_at: expires.toISOString() });
});

// Start
const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log(`Server ${APP_NAME} listening on ${PORT}`));
