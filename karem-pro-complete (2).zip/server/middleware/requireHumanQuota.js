const Database = require('../utils/db');
module.exports = async function requireHumanQuota(req, res, next) {
  const user = req.user;
  if (!user) return res.status(401).json({ error: 'مستخدم غير مصدق.' });
  if (user.is_subscriber) return next();
  const db = Database.get();
  let row = db.prepare('SELECT used_messages, free_quota FROM human_chat_counters WHERE user_id = ?').get(user.id);
  if (!row) {
    db.prepare('INSERT INTO human_chat_counters (user_id, used_messages, free_quota) VALUES (?, 0, 50)').run(user.id);
    row = { used_messages:0, free_quota:50 };
  }
  if (row.used_messages >= row.free_quota) {
    return res.status(403).json({ error: 'وصلت الحد المجاني من الرسائل. يرجى الاشتراك.' });
  }
  db.prepare('UPDATE human_chat_counters SET used_messages = used_messages + 1, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?').run(user.id);
  req.remaining_human = row.free_quota - (row.used_messages + 1);
  next();
};
