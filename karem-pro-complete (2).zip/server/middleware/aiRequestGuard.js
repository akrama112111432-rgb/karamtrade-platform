const Database = require('../utils/db');
function isComplexRequest(req) {
  const text = (req.body.text || '').trim();
  const hasAttachment = !!(req.files && Object.keys(req.files).length);
  const keywords = ['انشاء كود','تحليل متقدم','رسم','صورة','مخطط','generate code','create image','كود'];
  if (hasAttachment) return true;
  if (text.length > 300) return true;
  for (const k of keywords) if (text.toLowerCase().includes(k)) return true;
  return false;
}
async function aiRequestGuard(req, res, next) {
  const user = req.user;
  if (!user) return res.status(401).json({ error: 'مستخدم غير مصدق.' });
  const complex = isComplexRequest(req);
  if (complex && !user.is_subscriber) {
    return res.status(403).json({ error: 'هذه الميزة متاحة للمشتركين فقط. الرجاء الاشتراك.' });
  }
  const db = Database.get();
  const today = new Date().toISOString().slice(0,10);
  const row = db.prepare('SELECT requests FROM ai_usage_daily WHERE user_id = ? AND date = ?').get(user.id, today);
  const freeDailyLimit = user.is_subscriber ? 1000000 : 10;
  if (row && row.requests >= freeDailyLimit) {
    return res.status(429).json({ error: 'وصلت الحد اليومي من طلبات المساعد الذكي.' });
  }
  if (row) db.prepare('UPDATE ai_usage_daily SET requests = requests + 1 WHERE user_id = ? AND date = ?').run(user.id, today);
  else db.prepare('INSERT INTO ai_usage_daily (user_id, date, requests) VALUES (?, ?, 1)').run(user.id, today);
  next();
}
module.exports = { aiRequestGuard, isComplexRequest };
