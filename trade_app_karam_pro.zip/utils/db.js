const Database = require('better-sqlite3');
const dotenv = require('dotenv');
const path = require('path');
dotenv.config();
let db = null;
module.exports = {
  get: function() {
    if (!db) {
      const url = process.env.DATABASE_URL || './data/dev.db';
      db = new Database(url);
    }
    return db;
  }
};
