const express = require('express');
const app = express();
app.use(express.json());
let users = {
  'u_1': { id:'u_1', username:'Ali', balance:300, accountType:'standard' },
  'u_2': { id:'u_2', username:'Sara', balance:400, accountType:'islamic' }
};
app.get('/api/admin/users', (req,res)=> res.json({ users: Object.values(users) }));
app.post('/api/admin/set-account-type', (req,res)=>{
  const { userId, accountType } = req.body;
  if(!users[userId]) return res.status(404).json({error:'not found'});
  users[userId].accountType = accountType;
  return res.json({ ok:true, user: users[userId] });
});
app.listen(4000, ()=> console.log('Demo backend v4 running on 4000'));
