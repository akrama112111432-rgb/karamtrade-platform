// simple migration runner to initialize SQLite DB
const fs = require('fs');
const Database = require('better-sqlite3');
const sql = fs.readFileSync('./migrations/001_init.sql','utf8');
const path = require('path');
const dbPath = process.env.DATABASE_URL || './data/dev.db';
const dir = path.dirname(dbPath);
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
const db = new Database(dbPath);
db.exec(sql);
console.log('Migration applied to', dbPath);
