import React,{useState} from 'react';
import { SafeAreaView, View, Text, TouchableOpacity, TextInput, StyleSheet, Alert, ScrollView } from 'react-native';
export default function App(){
  const [loggedIn,setLoggedIn]=useState(false);
  const [userList,setUserList]=useState([{id:'u_1',username:'Ali',balance:300,accountType:'standard'},{id:'u_2',username:'Sara',balance:400,accountType:'islamic'}]);
  const [adminUser,setAdminUser]=useState(''); const [adminPass,setAdminPass]=useState('');
  const tryLogin=()=>{ if(adminUser==='karam' && adminPass==='Akram@Krm2025'){ setLoggedIn(true); } else Alert.alert('خطأ','بيانات الدخول غير صحيحة'); };

  const toggleAccountType = (id) => {
    setUserList(list=>list.map(u => u.id===id ? {...u, accountType: u.accountType==='islamic' ? 'standard' : 'islamic'} : u));
    Alert.alert('تم','تم تغيير نوع الحساب');
  };

  if(!loggedIn) return (
    <SafeAreaView style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.h1}>Admin Login</Text>
        <TextInput placeholder="Admin user" value={adminUser} onChangeText={setAdminUser} style={styles.input} />
        <TextInput placeholder="Admin pass" secureTextEntry value={adminPass} onChangeText={setAdminPass} style={styles.input} />
        <TouchableOpacity style={styles.btn} onPress={tryLogin}><Text style={{color:'white'}}>Login</Text></TouchableOpacity>
      </View>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.card}>
        <Text style={styles.h1}>لوحة التحكم الخاصة بكن: كرم</Text>
        {userList.map(u => (
          <View key={u.id} style={styles.userRow}>
            <Text>{u.username} — {u.balance} USD — {u.accountType}</Text>
            <View style={{flexDirection:'row', marginTop:8}}>
              <TouchableOpacity style={styles.smallBtn} onPress={()=>toggleAccountType(u.id)}><Text>تبديل نوع الحساب</Text></TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container:{flex:1, backgroundColor:'#F7F8FA'},
  card:{padding:16},
  h1:{fontSize:18, fontWeight:'700', marginBottom:12},
  input:{borderWidth:1,borderColor:'#ddd',padding:8, marginBottom:8, borderRadius:6},
  btn:{backgroundColor:'#0A84FF', padding:10, borderRadius:8, alignItems:'center'},
  userRow:{backgroundColor:'#fff', padding:10, marginBottom:8, borderRadius:8},
  smallBtn:{padding:8, backgroundColor:'#eee', borderRadius:6, marginRight:6}
});
