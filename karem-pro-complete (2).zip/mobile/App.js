import React from 'react';
import { SafeAreaView, Text, View, Button, TextInput, Alert } from 'react-native';
import axios from 'axios';
const API_BASE = 'https://REPLACE_WITH_YOUR_SERVER_URL';
export default function App(){ const [email,setEmail]=React.useState(''); const [name,setName]=React.useState(''); const register=async()=>{ try{ const r=await axios.post(`${API_BASE}/register`,{name,email}); Alert.alert('تم','تفاصيل التسجيل أرسلت'); }catch(e){ Alert.alert('خطأ',e.message||''); } }; return (<SafeAreaView style={{flex:1,padding:20}}><Text style={{fontSize:20,fontWeight:'bold',textAlign:'center'}}>كرم برو</Text><TextInput placeholder='الاسم' value={name} onChangeText={setName} style={{borderWidth:1,padding:10,marginVertical:10}}/><TextInput placeholder='الايميل' value={email} onChangeText={setEmail} style={{borderWidth:1,padding:10,marginBottom:10}} keyboardType='email-address' /><Button title='سجل وجرب مجاني' onPress={register} /></SafeAreaView>); }
